'use client';
import { useEffect, useRef, useState } from 'react';
import QRCode from 'qrcode';
import { fmtLegible, ETIQUETA_ESTADO } from '@/lib/cliente';

export function Error_({ e }: { e: any }) {
  if (!e) return null;
  const extra = e.detalle?.mensajes ? '\n- ' + e.detalle.mensajes.join('\n- ') : '';
  return <div className="err">{e.message}{extra}</div>;
}
export const Estado = ({ e }: { e: string }) => {
  const c = ['entregado', 'entregada', 'disponible_retiro'].includes(e) ? 'verde' : ['anulado', 'retenido', 'devuelto'].includes(e) ? 'rojo' : ['pendiente_redespacho', 'parcialmente_disponible'].includes(e) ? 'amarillo' : '';
  return <span className={`tag ${c}`}>{ETIQUETA_ESTADO[e] ?? e}</span>;
};

/** Resultado grande de color de un escaneo. */
export function ResultadoGrande({ r }: { r: any }) {
  if (!r) return null;
  const mapa: Record<string, [string, string]> = {
    ok: ['verde', 'CORRECTO'], repetido: ['amarillo', 'YA ESCANEADO (no suma)'], ya_a_bordo: ['amarillo', 'CONTINUA A BORDO'],
    no_esperado: ['rojo', 'NO CORRESPONDE'], conflicto_asignacion: ['rojo', 'CONFLICTO'], bloqueado: ['rojo', 'BLOQUEADO'],
    descarga_incorrecta: ['rojo', 'NO VIENE EN ESTE VIAJE'], debia_continuar: ['rojo', 'NO LO BAJE: CONTINUA'], desconocido: ['rojo', 'CODIGO DESCONOCIDO'],
  };
  const [color, texto] = mapa[r.resultado] ?? ['amarillo', String(r.resultado).toUpperCase()];
  return (
    <div className={`resultado ${color}`}>
      <div className="g">{texto}</div>
      {r.codigo && <div className="p mono">{fmtLegible(r.codigo)} {r.encomienda ? `· ${r.encomienda} #${r.numero ?? ''}` : ''}</div>}
      {r.alerta && <div className="p">{r.alerta}</div>}
      {r.incidencia && <div className="p">Incidencia abierta: {r.incidencia}</div>}
    </div>
  );
}

/** Escaner: campo de texto (lector Bluetooth o escribir) + camara con BarcodeDetector si el navegador la soporta. */
export function Scanner({ onCode, ocupado }: { onCode: (codigo: string) => void; ocupado?: boolean }) {
  const [txt, setTxt] = useState(''); const [cam, setCam] = useState(false); const [msg, setMsg] = useState('');
  const video = useRef<HTMLVideoElement>(null); const ultimo = useRef({ c: '', t: 0 }); const cb = useRef(onCode); cb.current = onCode;
  useEffect(() => {
    if (!cam) return;
    let stop = false; let stream: MediaStream | null = null;
    (async () => {
      try {
        const BD = (window as any).BarcodeDetector;
        if (!BD) { setMsg('Este navegador no lee QR con la camara. Escribe el codigo XXXX-XXXX.'); setCam(false); return; }
        const det = new BD({ formats: ['qr_code'] });
        stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
        if (video.current) { video.current.srcObject = stream; await video.current.play(); }
        const bucle = async () => {
          if (stop) return;
          try {
            const r = await det.detect(video.current!);
            if (r[0]) { const c = r[0].rawValue as string; const n = Date.now(); if (c !== ultimo.current.c || n - ultimo.current.t > 2500) { ultimo.current = { c, t: n }; cb.current(c); } }
          } catch { /* ignorar cuadros sin QR */ }
          setTimeout(bucle, 250);
        };
        bucle();
      } catch (e: any) { setMsg('No se pudo abrir la camara (necesita HTTPS o localhost): ' + (e?.message ?? e)); setCam(false); }
    })();
    return () => { stop = true; stream?.getTracks().forEach(t => t.stop()); };
  }, [cam]);
  const enviar = () => { const c = txt.trim(); if (c) { onCode(c); setTxt(''); } };
  return (
    <div>
      <div className="row">
        <label>Codigo (QR o XXXX-XXXX)
          <input autoFocus value={txt} onChange={e => setTxt(e.target.value)} onKeyDown={e => e.key === 'Enter' && enviar()} placeholder="Escanea o escribe y Enter" autoComplete="off" />
        </label>
        <button onClick={enviar} disabled={ocupado || !txt.trim()}>Enviar</button>
        <button className="sec" onClick={() => { setMsg(''); setCam(c => !c); }}>{cam ? 'Cerrar camara' : 'Usar camara'}</button>
      </div>
      {cam && <video ref={video} className="video" playsInline muted />}
      {msg && <div className="muted" style={{ marginTop: 6 }}>{msg}</div>}
    </div>
  );
}

/** Etiqueta del bulto: QR + codigo legible + destino grande. SIN datos personales. */
export function Etiqueta({ token, legible, destino, numero, total, encomienda }: { token: string; legible: string; destino: string; numero: number; total: number; encomienda: string }) {
  const [src, setSrc] = useState('');
  useEffect(() => { QRCode.toDataURL(token, { errorCorrectionLevel: 'M', margin: 1, width: 220 }).then(setSrc); }, [token]);
  return (
    <div className="etiqueta">
      <div className="dest">{destino}</div>
      {src && <img src={src} alt="QR" />}
      <div className="leg">{fmtLegible(legible)}</div>
      <div className="muted" style={{ color: '#000' }}>{encomienda} · Bulto {numero}/{total}</div>
    </div>
  );
}
