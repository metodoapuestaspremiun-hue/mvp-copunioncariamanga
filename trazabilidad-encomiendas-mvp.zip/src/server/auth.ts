import { cookies } from 'next/headers';
import { createHash, randomBytes } from 'node:crypto';
import { hash, verify } from '@node-rs/argon2';
import { pool, q, q1, ex } from './db';
import { ErrorNegocio, param } from './comun';
import type { SesionUsuario, Rol } from '@/shared/permisos';

const COOKIE = 'sid';
const sha = (s: string) => createHash('sha256').update(s).digest('hex');
export const hashPassword = (p: string) => hash(p);

async function cargarRoles(usuarioId: string) {
  const r = await q<{ rol: Rol; agencia_id: string | null }>(pool, 'SELECT rol, agencia_id FROM usuario_rol WHERE usuario_id=?', [usuarioId]);
  return r.map(x => ({ rol: x.rol, agenciaId: x.agencia_id }));
}

export async function verificarCredenciales(email: string, password: string): Promise<SesionUsuario | null> {
  const u = await q1<any>(pool, 'SELECT * FROM usuario WHERE email=? AND activo=1', [email.trim().toLowerCase()]);
  if (!u || u.password_hash === 'PENDIENTE') return null;
  let ok = false;
  try { ok = await verify(u.password_hash, password); } catch { ok = false; }
  if (!ok) return null;
  return { id: u.id, nombre: u.nombre, email: u.email, roles: await cargarRoles(u.id) };
}

export async function iniciarSesion(email: string, password: string): Promise<SesionUsuario> {
  const u = await verificarCredenciales(email, password);
  if (!u) throw new ErrorNegocio('CREDENCIALES_INVALIDAS', 'Correo o contrasena incorrectos', undefined, 401);
  const token = randomBytes(32).toString('hex');
  await ex(pool, 'INSERT INTO sesion(id,usuario_id,expira_at) VALUES (?,?,NOW(3) + INTERVAL 12 HOUR)', [sha(token), u.id]);
  (await cookies()).set(COOKIE, token, {
    httpOnly: true, sameSite: 'lax', path: '/', maxAge: 60 * 60 * 12,
    secure: process.env.COOKIE_SECURE === 'true',
  });
  return u;
}

export async function cerrarSesion() {
  const c = await cookies(); const t = c.get(COOKIE)?.value;
  if (t) await ex(pool, 'DELETE FROM sesion WHERE id=?', [sha(t)]);
  c.delete(COOKIE);
}

export async function sesionActual(): Promise<SesionUsuario | null> {
  const t = (await cookies()).get(COOKIE)?.value;
  if (!t) return null;
  const minutos = await param<number>(pool, 'sesion.inactividad_min', 60);
  const s = await q1<any>(pool,
    `SELECT u.id,u.nombre,u.email FROM sesion s JOIN usuario u ON u.id=s.usuario_id
      WHERE s.id=? AND s.expira_at>NOW(3) AND s.ultimo_uso_at > NOW(3) - INTERVAL ? MINUTE AND u.activo=1`, [sha(t), minutos]);
  if (!s) return null;
  await ex(pool, 'UPDATE sesion SET ultimo_uso_at=NOW(3) WHERE id=?', [sha(t)]);
  return { id: s.id, nombre: s.nombre, email: s.email, roles: await cargarRoles(s.id) };
}
