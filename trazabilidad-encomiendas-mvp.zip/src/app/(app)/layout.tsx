'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { llamar } from '@/lib/cliente';
import { SesionCtx } from '@/components/Sesion';
import { puede, type SesionUsuario } from '@/shared/permisos';

export default function AppLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const [u, setU] = useState<SesionUsuario | null>(null); const [tarifa, setTarifa] = useState<string | null>(null);
  useEffect(() => {
    llamar<SesionUsuario>('/api/auth/me').then(setU).catch(() => router.replace('/login'));
    llamar('/api/catalogos').then((c: any) => setTarifa(c.etiquetaTarifa)).catch(() => {});
  }, [router]);
  if (!u) return <main>Cargando...</main>;
  const salir = async () => { await llamar('/api/auth/logout', 'POST'); router.replace('/login'); };
  return (
    <SesionCtx.Provider value={u}>
      <nav className="top noprint">
        <b>Encomiendas</b>
        <Link href="/panel">Panel</Link>
        {puede(u, 'encomienda:crear') && <Link href="/encomiendas/nueva">Nueva encomienda</Link>}
        <Link href="/encomiendas">Encomiendas</Link>
        <Link href="/viajes">Viajes</Link>
        {puede(u, 'recepcion:confirmar') && <Link href="/recepcion">Recepcion</Link>}
        <Link href="/redespachos">Redespachos</Link>
        {puede(u, 'entrega:crear') && <Link href="/entrega">Entrega</Link>}
        <Link href="/incidencias">Incidencias</Link>
        {puede(u, 'ver:mensajes') && <Link href="/mensajes">Mensajes</Link>}
        <span className="sp" />
        <span>{u.nombre} ({[...new Set(u.roles.map(r => r.rol))].join(', ')})</span>
        <a href="#" onClick={e => { e.preventDefault(); salir(); }}>Salir</a>
      </nav>
      <div className="banner noprint">DEMOSTRACION con datos ficticios{tarifa ? ` · ${tarifa}` : ''}</div>
      <main>{children}</main>
    </SesionCtx.Provider>
  );
}
